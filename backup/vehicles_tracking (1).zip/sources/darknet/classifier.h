
list *read_data_cfg(char *filename);
