#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#define OPENCV

#include <QMainWindow>
#include <qfuture.h>
#include <qfuturewatcher.h>
#include <QtConcurrent\qtconcurrentrun.h>
#include <qevent.h>
#include <QFileDialog>
#include <QMessageBox>

#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/videoio/videoio.hpp>

#include <iostream>
#include <Windows.h>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include <thread>
#include <atomic>
#include <mutex>              // std::mutex, std::unique_lock
#include <condition_variable> // std::condition_variable
#include <cmath>
#include <map>

#include <yolo_v2_class.hpp>	// imported functions from DLL

#include "vehicle.h"
#include "video_viewer.h"

/* NOMINMAX */ // windows.h conflicts
#ifndef NOMINMAX   #ifndef max
#define max(a,b)  (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)  (((a) < (b)) ? (a) : (b))
#endif


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
	// attributes
	Detector detector;
	Detector logoDetector;
	Detector colorDetector;
	int fpsValue;
	int distance;
	std::vector<std::string> obj_names;
	std::vector<std::string> logo_names;
	std::vector<std::string> color_names;
	std::vector<std::string> obj_names_zh;
	std::vector<std::string> logo_names_zh;
	std::vector<std::string> color_names_zh;
	std::map<std::string, int> obj_numbers;
    Ui::MainWindow *ui;
	int viewerWidth;
	int viewerHeight;
	int videoWidth;
	int videoHeight;
	std::vector<Vehicle*> vehicles; // for vehicles inside screen
	std::vector<Vehicle*> vehiclesOut; // for vehicles already out of screen
	std::vector<box> lastBoxes; // objects in the last frame, used to calculate IoU
	int frameCounter;
	std::vector<std::pair<int, int>> ROI; // four points from left top clockwise
	cv::Mat emptyImg;
	cv::Mat ROIMask;
	cv::Mat currentFrame;
	bool paused;
	bool started;
	bool stopped;

	// methods
	void resizeEvent(QResizeEvent* event);
    void draw_boxes(cv::Mat mat_img, std::vector<bbox_t> result_vec, std::vector<std::string> obj_names,
        unsigned int wait_msec, int current_det_fps, int current_cap_fps);
    void show_console_result(std::vector<bbox_t> const result_vec, std::vector<std::string> const obj_names);
    std::vector<std::string> objects_names_from_file(std::string const filename);
	void trackVideo(std::string filePath);
	void diffVehicles(cv::Mat curFrame, std::vector<bbox_t> boxes/*, Detector color, Detector logo*/);
	void updateFrame(cv::Mat mat_img);
	void writeOutVehicle(int index); // write all screenshots to file system right after a vehicle run outside screen
	void processLastOne(int index/*, Detector color, Detector logo*/);
	std::string utf8(const std::string & str);

signals:
	void frameChanged(cv::Mat mat_img);
	void outputLogChanged(QString output);

private slots:
	void on_actionOpen_triggered();
	void selectROI(QMouseEvent* event);
	void on_reselect_clicked();
	void on_pause_clicked();
	void on_stop_clicked();
	void on_distance_valueChanged(double value);
	void updateLogOutput(QString output);
	// void updateFrame(cv::Mat mat_img);
};

#endif // MAINWINDOW_H
